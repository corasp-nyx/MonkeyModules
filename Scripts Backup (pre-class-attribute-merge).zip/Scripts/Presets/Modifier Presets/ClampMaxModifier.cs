﻿using System;
using System.Collections.Generic;

namespace TDP.ECS.Presets
{
    public class ClampMaxModifier : ValueModifier<float>
    {
        public override int priority { get; protected set; }

        private const string calculationEventKeySuffix = "-Calculate";

        protected ValueAttribute<float> max;

        public ClampMaxModifier(IEnumerable<ModifierRequirement> requirements, ValueAttribute<float> max, int priority = (int)ModifierPriority.clamp) : base(requirements)
        {
            this.priority = priority;
            this.max = max;
            max.OnChange.AddListener(NotifyOfVariableChange, uid + calculationEventKeySuffix);
        }

        public override void Modify(ref float value, Attribute attribute)
        {
            value = Math.Min(value, max.GetValue());
        }

        /// <returns>Whether Modifier minimum values match.</returns>
        protected override bool MatchesCalculationOf(ValueModifier<float> other)
        {
            return max == (other as ClampMaxModifier)?.max;
        }
    }

    public class ClampMaxConstantModifier : ValueModifier<float>
    {
        public override int priority { get; protected set; }

        protected float max;

        public ClampMaxConstantModifier(IEnumerable<ModifierRequirement> requirements, float max, int priority = (int)ModifierPriority.clamp) : base(requirements)
        {
            this.priority = priority;
            this.max = max;
        }

        public override void Modify(ref float value, Attribute attribute)
        {
            value = Math.Min(value, max);
        }

        /// <returns>Whether Modifier minimum values match.</returns>
        protected override bool MatchesCalculationOf(ValueModifier<float> other)
        {
            return max == (other as ClampMaxConstantModifier)?.max;
        }
    }
}
