﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TDP.ECS
{
    public static class ECSManager
    {
        private static readonly Dictionary<string, Event<Effect>> events;
        private static readonly List<Modifier> modifiers;
        //private static readonly List<Effect> effects;
        //private static readonly List<Attribute> attributes;

        public static readonly Event<Modifier> OnModifierPublished;

        static ECSManager()
        {
            events ??= new Dictionary<string, Event<Effect>>();
            modifiers ??= new List<Modifier>();
            //effects ??= new List<Effect>();
            //attributes ??= new List<Attribute>();

            OnModifierPublished = new Event<Modifier>();
        }

        /// <summary>
        /// Broadcasts an Event to all listeners.
        /// </summary>
        public static void InvokeEvent(string eventName, Effect invocationSource)
        {
            if (events.ContainsKey(eventName))
                events[eventName].Invoke(invocationSource);
        }

        /// <summary>
        /// Registers an Action to be invoked when the specified Event is called. The key can be used to unregister this Action. (duplicate keys are allowed)
        /// </summary>
        public static void AddEventListener(string eventName, Action<Effect> call, string listenerKey)
        {
            // create event if it does not exist yet
            if (!events.ContainsKey(eventName))
                events.Add(eventName, new Event<Effect>());

            // add listener
            events[eventName].AddListener(call, listenerKey);
        }

        /// <summary>
        /// Unregisters all listeners with specified key from specified Event.
        /// </summary>
        public static void RemoveEventListener(string eventName, string listenerKey)
        {
            if (events.ContainsKey(eventName))
                events[eventName].RemoveListener(listenerKey);
        }

        /// <summary>
        /// Registers a new Modifier to be applied to Attributes, excluding duplicates.
        /// </summary>
        /// <returns>The new Modifier if added, otherwise the already existing duplicate.</returns>
        public static Modifier AddModifier(Modifier modifier)
        {
            Modifier existingDuplicate = modifiers.FirstOrDefault(exMod => exMod.IsDuplicateOf(modifier));
            if (existingDuplicate == null)
            {
                modifiers.Add(modifier);

                // let all attributes check if the new modifier applies to them and perchance recalculate
                OnModifierPublished.Invoke(modifier);

                return modifier;
            }
            else
                return existingDuplicate;
        }

        public static void RemoveModifier(Modifier modifier)
        {
            modifiers.Remove(modifier);
        }

        /// <returns>All modifiers (does not return null)</returns>
        public static Modifier[] GetAllModifiers()
        {
            return modifiers.ToArray();
        }

        /// <returns>All modifiers that apply to specified attribute. (does not return null)</returns>
        public static Modifier[] GetApplicableModifiers(Attribute attribute)
        {
            return modifiers.Where(modifier => modifier.AppliesTo(attribute)).ToArray(); // (todo: increase search efficiency)
        }
    }
}
