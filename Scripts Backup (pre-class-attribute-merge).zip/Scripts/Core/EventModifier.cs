﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TDP.ECS
{
    /// <summary>
    /// A Modifier that invokes an Event when triggered by the value of an affected Attribute changing in a specified way. Does not apply any value modifications.
    /// </summary>
    /// <typeparam name="T">Affected Attribute value Type.</typeparam>
    public abstract class ValueEventModifier<T> : ValueModifier<T> where T : struct
    {
        public sealed override int priority { get; protected set; } = int.MinValue;

        /// <summary>Event called when the change of an affected Attribute's value matches triggering conditions.</summary>
        public readonly Event<ValueAttribute<T>> OnTriggered = new Event<ValueAttribute<T>>();

        private const string triggerEventKeySuffix = "-Trigger";

        public ValueEventModifier(IEnumerable<ModifierRequirement> requirements) : base(requirements) { }

        public sealed override void Modify(ref T value, Attribute attribute)
        {
            if (attribute is ValueAttribute<T>)
            {
                ValueAttribute<T> trigger = (ValueAttribute<T>)attribute;
                trigger.OnChange.RemoveListener(uid + triggerEventKeySuffix);
                T cachedValue = trigger.GetValue();
                trigger.OnChange.AddListener((_) => { trigger.OnChange.RemoveListener(uid + triggerEventKeySuffix); if (CheckTrigger(cachedValue, trigger.GetValue(), trigger)) OnTriggered.Invoke(trigger); }, uid + triggerEventKeySuffix);
            }
        }

        protected sealed override void NotifyOfVariableChange(List<Attribute> changedAttributes) => base.NotifyOfVariableChange(changedAttributes);

        /// <summary>
        /// Check if the change of an affected Attribute's value matches Event trigger conditions.
        /// </summary>
        protected abstract bool CheckTrigger(T oldValue, T newValue, ValueAttribute<T> attribute);
    }

    /// <summary>
    /// A Modifier that invokes an Event when triggered by the reference of an affected Attribute changing in a specified way. Does not apply any reference modifications.
    /// </summary>
    /// <typeparam name="T">Affected Attribute reference Type.</typeparam>
    public abstract class ReferenceEventModifier<T> : ReferenceModifier<T> where T : class
    {
        public sealed override int priority { get; protected set; } = int.MinValue;

        /// <summary>Event called when the change of an affected Attribute's value matches triggering conditions.</summary>
        public readonly Event<ReferenceAttribute<T>> OnTriggered = new Event<ReferenceAttribute<T>>();

        private const string triggerEventKeySuffix = "-Trigger";

        public ReferenceEventModifier(IEnumerable<ModifierRequirement> requirements) : base(requirements) { }

        public sealed override void Modify(ref T? reference, Attribute attribute)
        {
            if (attribute is ReferenceAttribute<T>)
            {
                ReferenceAttribute<T> trigger = (ReferenceAttribute<T>)attribute;
                trigger.OnChange.RemoveListener(uid + triggerEventKeySuffix);
                T? cachedReference = trigger.GetReference();
                trigger.OnChange.AddListener((_) => { trigger.OnChange.RemoveListener(uid + triggerEventKeySuffix); if (CheckTrigger(cachedReference, trigger.GetReference(), trigger)) OnTriggered.Invoke(trigger); }, uid + triggerEventKeySuffix);
            }
        }

        protected sealed override void NotifyOfVariableChange(List<Attribute> changedAttributes) => base.NotifyOfVariableChange(changedAttributes);

        /// <summary>
        /// Check if the change of an affected Attribute's reference matches Event trigger conditions.
        /// </summary>
        protected abstract bool CheckTrigger(T? oldValue, T? newValue, ReferenceAttribute<T> attribute);
    }

    public class ChangedValueEventModifier<T> : ValueEventModifier<T> where T : struct
    {
        public ChangedValueEventModifier(IEnumerable<ModifierRequirement> requirements) : base(requirements) { }

        protected override bool CheckTrigger(T oldValue, T newValue, ValueAttribute<T> attribute)
        {
            return !oldValue.Equals(newValue);
        }

        protected override bool MatchesCalculationOf(ValueModifier<T> other) => true;
    }

    public class IncreasedValueEventModifier : ValueEventModifier<float>
    {
        public IncreasedValueEventModifier(IEnumerable<ModifierRequirement> requirements) : base(requirements) { }

        protected override bool CheckTrigger(float oldValue, float newValue, ValueAttribute<float> attribute)
        {
            return newValue > oldValue;
        }

        protected override bool MatchesCalculationOf(ValueModifier<float> other) => true;
    }

    public class DecreasedValueEventModifier : ValueEventModifier<float>
    {
        public DecreasedValueEventModifier(IEnumerable<ModifierRequirement> requirements) : base(requirements) { }

        protected override bool CheckTrigger(float oldValue, float newValue, ValueAttribute<float> attribute)
        {
            return newValue < oldValue;
        }

        protected override bool MatchesCalculationOf(ValueModifier<float> other) => true;
    }

    public class TargetValueEventModifier<T> : ValueEventModifier<T> where T : struct
    {
        protected readonly T targetValue;

        public TargetValueEventModifier(IEnumerable<ModifierRequirement> requirements, T targetValue) : base(requirements)
        {
            this.targetValue = targetValue;
        }

        protected override bool CheckTrigger(T oldValue, T newValue, ValueAttribute<T> attribute)
        {
            return !oldValue.Equals(newValue) && newValue.Equals(targetValue);
        }

        protected override bool MatchesCalculationOf(ValueModifier<T> other)
        {
            return targetValue.Equals((other as TargetValueEventModifier<T>)?.targetValue);
        }
    }

    public class ChangedReferenceEventModifier<T> : ReferenceEventModifier<T> where T : class
    {
        public ChangedReferenceEventModifier(IEnumerable<ModifierRequirement> requirements) : base(requirements) { }

        protected override bool CheckTrigger(T? oldReference, T? newReference, ReferenceAttribute<T> attribute)
        {
            return oldReference != newReference;
        }

        protected override bool MatchesCalculationOf(ReferenceModifier<T> other) => true;
    }

    public class TargetReferenceEventModifier<T> : ReferenceEventModifier<T> where T : class
    {
        protected readonly T? targetReference;

        public TargetReferenceEventModifier(IEnumerable<ModifierRequirement> requirements, T targetReference) : base(requirements)
        {
            this.targetReference = targetReference;
        }

        protected override bool CheckTrigger(T? oldReference, T? newReference, ReferenceAttribute<T> attribute)
        {
            return oldReference != newReference && newReference == targetReference;
        }

        protected override bool MatchesCalculationOf(ReferenceModifier<T> other)
        {
            return targetReference == (other as TargetReferenceEventModifier<T>)?.targetReference;
        }
    }
}
