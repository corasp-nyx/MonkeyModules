﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TDP.ECS
{
    /// <summary>
    /// Invocable Event with a single payload.
    /// </summary>
    /// <typeparam name="T">Payload Type.</typeparam>
    public class Event<T>
    {
        protected List<KeyValuePair<string, Action<T>>>? listeners;

        /// <summary>
        /// Invokes listening Actions and passes along a Payload.
        /// </summary>
        /// <returns>Success</returns>
        public bool Invoke(T payload)
        {
            if (listeners != null)
                foreach (Action<T> call in listeners.Select(listener => listener.Value))
                    call.Invoke(payload);

            return true;
        }

        /// <summary>
        /// Registers an Action to be invoked when this Event is called. The key can be used to unregister this Action. (duplicate keys are allowed)
        /// </summary>
        public void AddListener(Action<T> call, string key)
        {
            listeners ??= new List<KeyValuePair<string, Action<T>>>();

            // register Action
            listeners.Add(new KeyValuePair<string, Action<T>>(key, call));
        }

        /// <summary>
        /// Registers an Action to be invoked when this Event is called, ignoring Payload. The key can be used to unregister this Action. (duplicate keys are allowed)
        /// </summary>
        public void AddListener(Action call, string key)
        {
            // register Action ignoring payload
            AddListener((source) => call.Invoke(), key);
        }

        /// <summary>
        /// Unregisters all listeners with specified key.
        /// </summary>
        public void RemoveListener(string key)
        {
            listeners?.RemoveAll(listener => listener.Key == key);
        }

        public void ClearListeners()
        {
            listeners = null;
        }
    }
}
