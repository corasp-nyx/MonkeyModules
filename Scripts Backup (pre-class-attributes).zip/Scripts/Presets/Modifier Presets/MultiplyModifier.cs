﻿using System;
using System.Collections.Generic;

namespace TDP.ECS.Presets
{
    public class MultiplyModifier : Modifier<float>
    {
        public override int priority { get; protected set; }

        private const string calculationEventKeySuffix = "-Calculate";

        protected Attribute<float> multiplier;

        public MultiplyModifier(IEnumerable<ModifierRequirement> requirements, Attribute<float> multiplier, int priority = (int)ModifierPriority.mainMul) : base(requirements)
        {
            this.priority = priority;
            this.multiplier = multiplier;
            multiplier.OnChange.AddListener(NotifyOfVariableChange, uid + calculationEventKeySuffix);
        }

        public override void Modify(ref float value, Attribute attribute)
        {
            value = value * multiplier.GetValue();
        }

        /// <returns>Whether Modifier multipliers match.</returns>
        protected override bool MatchesCalculationOf(Modifier<float> other)
        {
            return multiplier == (other as MultiplyModifier)?.multiplier;
        }
    }

    public class MultiplyConstantModifier : Modifier<float>
    {
        public override int priority { get; protected set; }

        protected float multiplier;

        public MultiplyConstantModifier(IEnumerable<ModifierRequirement> requirements, float multiplier, int priority = (int)ModifierPriority.mainMul) : base(requirements)
        {
            this.priority = priority;
            this.multiplier = multiplier;
        }

        public override void Modify(ref float value, Attribute attribute)
        {
            value = value * multiplier;
        }

        /// <returns>Whether Modifier multipliers match.</returns>
        protected override bool MatchesCalculationOf(Modifier<float> other)
        {
            return multiplier == (other as MultiplyConstantModifier)?.multiplier;
        }
    }
}
