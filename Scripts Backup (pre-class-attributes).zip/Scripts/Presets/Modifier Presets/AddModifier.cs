﻿using System;
using System.Collections.Generic;

namespace TDP.ECS.Presets
{
    public class AddModifier : Modifier<float>
    {
        public override int priority { get; protected set; }

        private const string calculationEventKeySuffix = "-Calculate";

        protected Attribute<float> addend;

        public AddModifier(IEnumerable<ModifierRequirement> requirements, Attribute<float> addend, int priority = (int)ModifierPriority.mainAdd) : base(requirements)
        {
            this.priority = priority;
            this.addend = addend;
            addend.OnChange.AddListener(NotifyOfVariableChange, uid + calculationEventKeySuffix);
        }

        public override void Modify(ref float value, Attribute attribute)
        {
            value = value + addend.GetValue();
        }

        /// <returns>Whether Modifier addends match.</returns>
        protected override bool MatchesCalculationOf(Modifier<float> other)
        {
            return addend == (other as AddModifier)?.addend;
        }
    }

    public class AddConstantModifier : Modifier<float>
    {
        public override int priority { get; protected set; }

        protected float addend;

        public AddConstantModifier(IEnumerable<ModifierRequirement> requirements, float addend, int priority = (int)ModifierPriority.mainAdd) : base(requirements)
        {
            this.priority = priority;
            this.addend = addend;
        }
        
        public override void Modify(ref float value, Attribute attribute)
        {
            value = value + addend;
        }

        /// <returns>Whether Modifier addends match.</returns>
        protected override bool MatchesCalculationOf(Modifier<float> other)
        {
            return addend == (other as AddConstantModifier)?.addend;
        }
    }
}
